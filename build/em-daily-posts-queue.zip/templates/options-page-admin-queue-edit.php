<?php
/**
 * Admin Queue Edit Page Markup
 * This template renders the queue with reorder and delete controls for each item.
 * Usage: include this file from your class function for the admin queue edit page.
 */
if (!isset($queue_list) || !is_array($queue_list)) {
    $queue_list = [];
}
?>
<div class="edpq-admin-queue-wrap">
    <h1>Edit Photo Submission Queue</h1>
    <?php if (current_user_can('manage_options')): ?>
    <a href="<?php echo esc_url(add_query_arg('import_demo', '1')); ?>" class="button" style="margin-bottom:15px;">Import Demo Submissions</a>
    <?php endif; ?>
    <form id="admin-queue-edit-form" method="post">
        <div id="queue-list">
            <?php foreach ($queue_list as $item): ?>
            <!-- Conflict warning will be injected by JS as .edpq-conflict-warning -->    
                <?php $post_title = get_the_title($item['postid']); ?>
                <div class="queue-row" data-postid="<?php echo esc_attr($item['postid']); ?>" data-queuenumber="<?php echo esc_attr($item['queueNumber']); ?>" data-posttitle="<?php echo esc_attr($post_title); ?>">
                    <span class="queue-title"><?php echo esc_html($post_title); ?> (Post ID: <?php echo esc_html($item['postid']); ?>)</span>
                    <button type="button" class="queue-up">&#8593; Up</button>
                    <button type="button" class="queue-down">&#8595; Down</button>
                    <button type="button" class="queue-delete">Delete</button>
                    <input type="hidden" name="queue-postID-<?php echo esc_attr($item['queueNumber']); ?>" value="<?php echo esc_attr($item['postid']); ?>">
                    <input type="hidden" name="queue-value-<?php echo esc_attr($item['queueNumber']); ?>" value="<?php echo esc_attr($item['queueNumber']); ?>">
                </div>
            <?php endforeach; ?>
        </div>
        <button type="submit" class="button button-primary">Save Queue Order</button>
        <?php if (current_user_can('manage_options')): ?>
        <button type="button" id="full-wipe-btn" class="button button-danger" style="margin-left:10px;">Full Wipe</button>
        <?php endif; ?>
    </form>
</div>
