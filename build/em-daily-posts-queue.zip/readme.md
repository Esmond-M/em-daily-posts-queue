Project: [https://github.com/Esmond-M/em-daily-posts-queue](https://github.com/Esmond-M/em-daily-posts-queue)<br>
Author: [esmondmccain.com](https://esmondmccain.com/)
## History
Originally made for AWC. Being put into a plugin for future use.
## Features
This plugin adds a Custom Post type "Net Submissions". It can display on the frond end using a template. This plugin is used in conjuncton with the "Action Scheduler" plugin.
 ## Installation

1. Download the latest version from [https://github.com/Esmond-M/em-daily-posts-queue/blob/main/build/em-daily-posts-queue.zip](https://github.com/Esmond-M/em-daily-posts-queue/blob/main/build/em-daily-posts-queue.zip).
2. Upload `em-daily-posts-queue` zip to the `/wp-content/plugins/` directory.
3. Extract zip folder. Folder name of plugin should be "em-daily-posts-queue".
4. Activate the plugin through the 'Plugins' menu in WordPress.



